# GESPA Solar Energy - Technical Specification

## Component Inventory

### shadcn/ui Components (Built-in)
- **Button** - CTAs, navigation actions
- **Card** - Product cards, feature cards, project cards
- **Accordion** - FAQ section
- **Badge** - Category labels, tags
- **Input** - Contact form
- **Textarea** - Contact form message
- **Sheet** - Mobile navigation drawer
- **Separator** - Visual dividers
- **ScrollArea** - Smooth scrolling containers

### Custom Components
- **AnimatedCounter** - Number counting animation for stats
- **ScrollReveal** - Intersection Observer based reveal animation wrapper
- **ParallaxImage** - Parallax scrolling image component
- **MobileNav** - Mobile navigation menu with animations

### Animation Libraries
- **Framer Motion** - React component animations, gestures, AnimatePresence
- **Intersection Observer API** - Scroll-triggered animations (native)

---

## Animation Implementation Table

| Animation | Library | Implementation Approach | Complexity |
|-----------|---------|------------------------|------------|
| Page load hero reveal | Framer Motion | staggerChildren + variants | Medium |
| Navbar scroll shadow | React state + CSS | useScroll hook, conditional classes | Low |
| Scroll-triggered section reveals | Framer Motion | whileInView + viewport | Medium |
| Card hover lift effect | CSS/Framer Motion | hover variants or CSS transition | Low |
| Button hover scale | CSS | transform: scale(1.02) | Low |
| Image hover zoom | CSS | transform: scale(1.05) with overflow:hidden | Low |
| Stats counter animation | Custom hook | useCountUp with Intersection Observer | Medium |
| Accordion expand/collapse | Framer Motion | AnimatePresence + height animation | Medium |
| Mobile menu slide | Framer Motion | AnimatePresence + x animation | Medium |
| Parallax hero image | Framer Motion | useScroll + useTransform | Medium |
| Staggered card reveals | Framer Motion | staggerChildren in parent | Medium |
| Icon rotation on hover | CSS/Framer Motion | rotate: 10deg | Low |

---

## Animation Library Choices

### Primary: Framer Motion
**Rationale:**
- Native React integration with declarative API
- Built-in scroll-triggered animations (whileInView)
- AnimatePresence for mount/unmount animations
- Gesture support for hover/tap states
- Excellent performance with hardware acceleration

### Secondary: CSS Transitions
**Rationale:**
- Simple hover effects (scale, color changes)
- No JavaScript overhead for basic interactions
- Better performance for simple transforms

### Utility: Intersection Observer (Native)
**Rationale:**
- Lightweight scroll detection
- Used for triggering Framer Motion animations
- No library dependency for basic detection

---

## Project File Structure

```
/mnt/okcomputer/output/app/
├── public/
│   └── images/
│       ├── hero-house.jpg
│       ├── about-team.jpg
│       ├── products/
│       │   ├── solar-panels.jpg
│       │   ├── inverters.jpg
│       │   ├── batteries.jpg
│       │   └── lighting.jpg
│       └── projects/
│           ├── project-1.jpg
│           ├── project-2.jpg
│           └── project-3.jpg
├── src/
│   ├── components/
│   │   ├── ui/              # shadcn components
│   │   ├── AnimatedCounter.tsx
│   │   ├── ScrollReveal.tsx
│   │   ├── MobileNav.tsx
│   │   └── SectionHeader.tsx
│   ├── sections/
│   │   ├── Header.tsx
│   │   ├── Hero.tsx
│   │   ├── Features.tsx
│   │   ├── About.tsx
│   │   ├── Products.tsx
│   │   ├── Projects.tsx
│   │   ├── Stats.tsx
│   │   ├── FAQ.tsx
│   │   ├── CTA.tsx
│   │   └── Footer.tsx
│   ├── hooks/
│   │   ├── useScrollPosition.ts
│   │   └── useCountUp.ts
│   ├── lib/
│   │   └── utils.ts
│   ├── App.tsx
│   ├── App.css
│   ├── index.css
│   └── main.tsx
├── index.html
├── tailwind.config.js
├── vite.config.ts
└── package.json
```

---

## Dependencies

### Core (Auto-installed)
- react
- react-dom
- typescript
- vite
- tailwindcss
- @radix-ui/* (via shadcn)

### Animation
- framer-motion

### Icons
- lucide-react

### Fonts
- @fontsource/poppins
- @fontsource/inter

---

## Installation Commands

```bash
# Initialize project
cd /mnt/okcomputer/output/app

# Install animation library
npm install framer-motion

# Install fonts
npm install @fontsource/poppins @fontsource/inter

# Add shadcn components
npx shadcn add button card accordion badge input textarea sheet separator scroll-area
```

---

## Color Configuration (Tailwind)

```javascript
// tailwind.config.js colors extension
colors: {
  primary: {
    DEFAULT: '#1a5f2a',
    light: '#2d8a4e',
  },
  accent: {
    DEFAULT: '#f4a020',
    dark: '#e8941f',
  },
  dark: '#1a1a1a',
  body: '#4a4a4a',
  'light-gray': '#f5f5f5',
  'sky-blue': '#e8f4f8',
  'sun-yellow': '#fff8e7',
  'eco-green': '#e8f5e9',
}
```

---

## Animation Timing Reference

| Animation Type | Duration | Easing |
|---------------|----------|--------|
| Hover effects | 200ms | ease-out |
| Card reveals | 600ms | cubic-bezier(0.16, 1, 0.3, 1) |
| Hero load | 800ms | cubic-bezier(0.16, 1, 0.3, 1) |
| Counter | 2000ms | ease-out |
| Accordion | 300ms | ease-in-out |
| Mobile menu | 400ms | cubic-bezier(0.16, 1, 0.3, 1) |

---

## Performance Considerations

1. **will-change**: Apply to animated elements
2. **transform/opacity only**: Avoid animating layout properties
3. **Lazy loading**: Images below fold
4. **Reduced motion**: Respect prefers-reduced-motion
5. **Code splitting**: Dynamic imports for heavy sections
